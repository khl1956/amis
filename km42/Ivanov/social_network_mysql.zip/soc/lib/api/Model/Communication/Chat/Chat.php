<?php
/**
 * User: dimasik142
 * User: ivanov.dmytro.ua@gmail.com
 * Date: 21.01.2018
 * Time: 04:21
 */

namespace Sql\Communication\Chat;

use Sql\Communication\Communication;
use Sql\Sql;

class Chat extends Communication
{

    /**
     * @param $userId
     * @param $idReceiver
     * @param $quantity
     * @return array|bool
     */
    public function getMessagesList($userId , $idReceiver, $quantity) {
        $sqlObj = new Sql();
        $connect = $sqlObj->connection();
        $sqlQuery = self::makeSelectLimitedString(
            $this->messagesTableName,
            '((`sender_id` = '. $idReceiver . ' AND `receiver_id` = '. $userId .') OR (`receiver_id` = ' . $idReceiver . " AND `sender_id` = " . $userId . ")) ",
            '*',
            $quantity,
            'ASC'
        );

        $queryResult = $connect->query($sqlQuery);
        if ($queryResult->num_rows > 0) {
            $information_array = $queryResult->fetch_all(MYSQLI_ASSOC);
            return $information_array;
        } else {
            return false;
        }
    }

    /**
     * @param $messageId
     * @return bool
     */
    public function deleteMessage($messageId) {
        $sqlObj = new Sql();
        $connect = $sqlObj->connection();
        $sqlQuery = self::makeDeleteString(
            $this->messagesTableName,
            '`id` = ' . $messageId
        );
        $connect->query($sqlQuery);
        return true;
    }

    /**
     * @param $messageId
     * @param $text
     * @return bool
     */
    public function changeMessage($messageId, $text) {
        $sqlObj = new Sql();
        $connect = $sqlObj->connection();
        $sqlQuery = self::makeUpdateString(
            $this->messagesTableName,
            '`text` = "'. $text . '"',
            '`id` = "' . $messageId . '"'
        );
        $connect->query($sqlQuery);
        return true;
    }
}