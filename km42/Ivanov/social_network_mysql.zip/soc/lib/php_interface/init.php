<?php
/**
 * Created by PhpStorm.
 * User: dimasik142
 * Date: 14.01.2018
 * Time: 4:40
 */
session_start();

require_once 'autoload.php';
