<?php
/**
 * Created by PhpStorm.
 * User: dimasik142
 * Date: 16.01.2018
 * Time: 13:53
 */

include($_SERVER["DOCUMENT_ROOT"].'/lib/api/User/UserMethods.php');
include($_SERVER["DOCUMENT_ROOT"].'/lib/api/Model/Sql.php');
include($_SERVER["DOCUMENT_ROOT"].'/lib/api/Model/Person/Person.php');
include($_SERVER["DOCUMENT_ROOT"].'/lib/api/Model/Communication/Communication.php');
include($_SERVER["DOCUMENT_ROOT"].'/lib/api/Model/Communication/Dialogs/Dialogs.php');
include($_SERVER["DOCUMENT_ROOT"].'/lib/api/Model/Communication/Chat/Chat.php');
