<?php
/**
 * User: dimasik142
 * User: ivanov.dmytro.ua@gmail.com
 * Date: 20.01.2018
 * Time: 23:01
 */
?>
<?php require($_SERVER["DOCUMENT_ROOT"]."/templates/main/header.php"); ?>
<div class="main_window">
    <div class="title">
        dimasik124214
    </div>
    <div>
        <div class ="div_photo">
            <p id ="lena"><img id ="photo_low_quality" src="/upload/images/1.jpg"></p>
            <br>
        </div>
        <div class="information">
    asdasdasd
            asd
            as
            da
            sd
            as
            dsa
            d
        </div>
    </div>
</div>
<?php require($_SERVER["DOCUMENT_ROOT"]."/templates/main/footer.php"); ?>
